<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

route::get("/", [Controller::Class,"index"])->name("index");
route::get("/tablasMultiplicar", [Controller::Class,"tablas"])->name("tablas");
route::get("/tablasMultiplicar/{numero}", [Controller::Class,"mostrarTablas"])->name("mostrarTablas");
