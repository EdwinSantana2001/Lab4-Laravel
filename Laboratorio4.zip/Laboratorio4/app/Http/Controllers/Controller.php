<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    Function index (){
        return view("index");
    }

    function tablas(){
        for ($i=0; $i <= 20 ; $i++)
            $numeros[] = ["valor"=>$i];
        //return $numeros ;
        return view("tablas",["numeros"=>$numeros]);
    }

    function mostrarTablas($numero){
        for ($i=0; $i <=12 ; $i++){
            $resultado = $i * $numero;
            $calculo = $i ." x " . $numero . " = " .$resultado;
            $filas[] = ["calculo"=>$calculo, "resultado"=>$resultado];
        }
        return view("mostrarTablas", ["filas"=>$filas]);
    }

}
